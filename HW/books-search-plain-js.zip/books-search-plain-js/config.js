//Google Books API key
const GAPI_KEY = "AIzaSyAkbKagSOHjlU7PsBsc6pcR-jY5b6xUOvg";
const API_URL = "https://www.googleapis.com/books/v1/volumes?q=";
export {GAPI_KEY,API_URL};