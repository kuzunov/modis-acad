//Google Books API key
const GAPI_KEY = "AIzaSyAkbKagSOHjlU7PsBsc6pcR-jY5b6xUOvg";
const API_URL = "https://www.googleapis.com/books/v1/volumes?q=";
const DB_URL = "http://localhost:3000/api/"
const ANNO_URL = `${DB_URL}annotations`;
const FAV_URL = `${DB_URL}favs`
export {GAPI_KEY,API_URL, ANNO_URL, DB_URL,FAV_URL};