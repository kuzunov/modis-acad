import { IdType } from "./sharedTypes";

export interface IPlace {
    id:IdType;
    location: google.maps.LatLng
    description?: string,
}