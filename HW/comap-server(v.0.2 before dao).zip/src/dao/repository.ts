import { promises } from "fs"
import { Identifiable, IdType } from "../model/sharedTypes"

export interface IRepository<T> {
    create(entity:T):Promise<T>
    update(entity:T):Promise<T>
    deleteById(id:IdType):Promise<T>
    findAll(entity:T):Promise<T[]>
    findById(id:IdType):Promise<T>
    count(entity:T):Promise<number>
}

export class RepositoryImpl<T extends Identifiable<IdType>> implements IRepository<T> {
    constructor(private dbFile:string){}

    async create(entity: T): Promise<T> {
        const entities = await this.findAll();
        const index = entities.findIndex(entityToUpdate => entity.id === entityToUpdate.id);
        entities[index] = entity;
        this.writeJsonToFile(entities);
        return entity;
    }
    async update(entity: T): Promise<T> {
        const entities = await this.findAll();
        const index = entities.findIndex(entityToUpdate => entity.id === entityToUpdate.id);
        entities[index] = entity;
        this.writeJsonToFile(entities);
        return entity;

    }
    async deleteById(id: string): Promise<T> {
        const entities = await this.findAll();
        const indexToDelete = entities.findIndex(dbEntity => dbEntity.id === id);
        const deletedEntity = entities[indexToDelete];
        entities.splice(indexToDelete,1);
        return deletedEntity;
    }
    async findAll(): Promise<T[]> {
        return this.getJsonFromFile();   
    }
    async findById(id: string): Promise<T> {
        const entities = await this.getJsonFromFile();
        const entity:T = entities.find(entity => entity.id === id);
        return entity;
    }
    async count(): Promise<number> {
        const entities = await this.getJsonFromFile();
        return entities.length;
    }

    private getJsonFromFile = async () => {
        const fileData = await promises.readFile(this.dbFile)
        const JSONentity = JSON.parse(fileData.toString());
        return JSONentity;
    }
    private writeJsonToFile = async (entity) => {
        promises.writeFile(this.dbFile, JSON.stringify(entity));
    }

}