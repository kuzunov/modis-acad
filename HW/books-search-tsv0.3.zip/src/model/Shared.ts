export type IdType = string|number|undefined;
export default interface Identifiable {
    id:IdType,
}