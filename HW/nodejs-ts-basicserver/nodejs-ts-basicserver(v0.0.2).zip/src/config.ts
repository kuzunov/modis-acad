export const DB_FILE = "./db.json";
export const HOSTNAME = "localhost";
export const PORT = 36000;