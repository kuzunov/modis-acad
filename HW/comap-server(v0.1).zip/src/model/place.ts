export interface IPlace {
    id:string;
    location: google.maps.LatLng
    description?: string,
}